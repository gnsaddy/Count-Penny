create definer = root@localhost view flexibleData as (select `u`.`userId`         AS `userId`,
                                                             `E`.`expenseId`      AS `expenseId`,
                                                             sum(`FE`.`flAmount`) AS `fl`
                                                      from (((`expenseManagement`.`User` `u` join `expenseManagement`.`HasExpense` `HE` on ((`u`.`userId` = `HE`.`userId`))) join `expenseManagement`.`Expense` `E` on ((`HE`.`expenseId` = `E`.`expenseId`)))
                                                               join `expenseManagement`.`FlexibleExpense` `FE`
                                                                    on ((`E`.`expenseId` = `FE`.`expenseId`)))
                                                      group by `u`.`userId`);

