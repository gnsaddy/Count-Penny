create definer = root@localhost view fixedData as (select `u`.`userId`         AS `userId`,
                                                          `E`.`expenseId`      AS `expenseId`,
                                                          sum(`FE`.`fxAmount`) AS `fx`
                                                   from (((`expenseManagement`.`User` `u` join `expenseManagement`.`HasExpense` `HE` on ((`u`.`userId` = `HE`.`userId`))) join `expenseManagement`.`Expense` `E` on ((`HE`.`expenseId` = `E`.`expenseId`)))
                                                            join `expenseManagement`.`FixedExpense` `FE`
                                                                 on ((`E`.`expenseId` = `FE`.`expenseId`)))
                                                   group by `u`.`userId`);

