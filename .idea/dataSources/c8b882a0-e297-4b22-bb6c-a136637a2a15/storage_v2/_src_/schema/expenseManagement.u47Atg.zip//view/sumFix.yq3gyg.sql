create definer = root@localhost view sumFix as (select `E`.`expenseDate`    AS `expenseDate`,
                                                       sum(`FE`.`fxAmount`) AS `sum(FE.fxAmount)`
                                                from (((`expenseManagement`.`HasExpense` `he` join `expenseManagement`.`User` `U` on ((`he`.`userId` = `U`.`userId`))) join `expenseManagement`.`Expense` `E` on ((`he`.`expenseId` = `E`.`expenseId`)))
                                                         join `expenseManagement`.`FixedExpense` `FE`
                                                              on ((`E`.`expenseId` = `FE`.`expenseId`)))
                                                group by `U`.`userId`);

