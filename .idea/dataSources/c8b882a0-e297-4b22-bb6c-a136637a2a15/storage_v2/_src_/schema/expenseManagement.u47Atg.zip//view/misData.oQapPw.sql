create definer = root@localhost view misData as (select `E`.`expenseDate`        AS `expenseDate`,
                                                        sum(`E`.`miscelleneous`) AS `sum(miscelleneous)`
                                                 from ((`expenseManagement`.`HasExpense` `he` join `expenseManagement`.`User` `U` on ((`he`.`userId` = `U`.`userId`)))
                                                          join `expenseManagement`.`Expense` `E`
                                                               on ((`he`.`expenseId` = `E`.`expenseId`)))
                                                 group by `U`.`userId`);

